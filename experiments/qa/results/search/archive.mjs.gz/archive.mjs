import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,copyFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {gzipSync,gunzipSync} from 'node:zlib';
import {digest,json} from '/home/mpd/git-sources/vizzi/experiments/qa/support.mjs';
import {verifyHashes} from '/home/mpd/git-sources/vizzi/experiments/qa/compact-support.mjs';
import {rankingRequest,parseOrder,assessSearch} from '/home/mpd/git-sources/vizzi/experiments/qa/search-support.mjs';
const output='experiments/qa/results/search',run='/tmp/vizzi-search-run',prepared='/tmp/vizzi-search-prepared';
const save=(path,value)=>writeFile(path,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const gzip=async(from,to)=>writeFile(to,gzipSync(await readFile(from)),{flag:'wx'});
const lines=async path=>(await readFile(path,'utf8')).trim().split('\n').map(JSON.parse);
const inputs=await json(join(prepared,'inputs.json')),ratings=await json(join(prepared,'relevance.json')),freeze=await json(join(run,'freeze.json'));
const rows=await lines(join(run,'rankings.jsonl')),raw=await lines(join(run,'responses.jsonl')),manifest=await json(join(run,'manifest.json'));
const index=await json(join(run,'native.json')),runtime=await json(join(run,'runtime.json')),memory=await json('/tmp/vizzi-search.memory.json');
await verifyHashes(freeze.files);
assert.equal(rows.length,6);assert.equal(raw.length,6);assert.equal(manifest.completed,6);assert.equal(manifest.modelRequests,6);assert.equal(manifest.incomplete,false);assert.equal(manifest.reservedGenerations,0);
assert.ok(Date.parse(ratings.auditedAt)<=Date.parse(freeze.createdAt));assert.ok(Date.parse(freeze.createdAt)<=Date.parse(manifest.createdAt));
const spec=await json('experiments/qa/library/search/cohort.json');
assert.equal(await digest('/tmp/vizzi-qa-runtime/llama-b12110/llama-server'),spec.runtimeSha256);
assert.equal(await digest('/tmp/vizzi-qa-weight-edit/models/base/model-q4.gguf'),manifest.model.sha256);
const assessed=assessSearch(inputs,rows,Object.fromEntries(Object.entries(ratings.cases).map(([id,r])=>[id,r.grades])));
assert.deepEqual(assessed,await json(join(run,'assessment.json')));
for(const [i,row] of rows.entries()){
 const input=inputs.find(x=>x.case===row.case);
 assert.deepEqual(row.request,rankingRequest(input,input.context,row.reverse));
 assert.deepEqual(parseOrder(row.raw),row.result.context.evidence.map(e=>e.label));assert.equal(row.result.kind,'suggested');assert.equal(row.transportError,null);
 assert.deepEqual(raw[i].response,row.response);assert.deepEqual(raw[i].request,row.request);assert.equal(raw[i].raw,row.raw);
 assert.equal(row.response.timings.cache_n,0);assert.equal(row.response.usage.prompt_tokens_details.cached_tokens,0);
 assert.equal(row.response.timings.prompt_n,row.response.usage.prompt_tokens);assert.equal(row.response.usage.completion_tokens,28);
 assert.equal(row.response.choices[0].finish_reason,'stop');
}
for(const input of inputs){
 const a=rows.find(r=>r.case===input.case&&!r.reverse),b=rows.find(r=>r.case===input.case&&r.reverse);
 const pa=JSON.parse(a.request.messages[1].content),pb=JSON.parse(b.request.messages[1].content);
 assert.deepEqual({...pb,candidates:[...pb.candidates].reverse()},pa);
 assert.deepEqual({...a.request,messages:[]},{...b.request,messages:[]});assert.equal(a.request.messages[0].content,b.request.messages[0].content);
}
assert.equal(memory.success,true);assert.equal(memory.mode,'observe_only');assert.equal(memory.cap_verified,false);assert.deepEqual(memory.errors,[]);
for(const sample of memory.samples)assert.deepEqual(sample.errors,[]);
for(const {pid} of [index,runtime])assert.throws(()=>process.kill(pid,0),{code:'ESRCH'});
const times=rows.map(r=>r.modelMs).sort((a,b)=>a-b),retrieval=await lines(join(run,'retrieval.jsonl'));
const summary={schema:1,knownQuestions:3,candidates:inputs.map(i=>({case:i.case,returned:i.context.evidence.length,literalBytes:i.context.evidence.reduce((n,e)=>n+Buffer.byteLength(e.text),0),missingExpectedSources:ratings.cases[i.case].missing_expected_sources})),modelRequests:6,validCompleteOrders:6,sourceBindingValid:6,baselineFallbacks:0,reservedGenerations:0,medianAdditionalRankingMs:(times[2]+times[3])/2,maxAdditionalRankingMs:times.at(-1),rankingMs:rows.map(r=>({id:r.id,ms:r.modelMs})),nativeIndexMs:index.ready.index_ms,modelStartupMs:runtime.startupMs,retrievalMs:retrieval.map(r=>({case:r.case,ms:r.elapsed_ms})),peakPssKiB:memory.peak_pss_kib,peakPssGiB:memory.peak_pss_kib/1048576,wholeObservedMs:memory.wall_ms,samplingErrors:0,within4GiBObservedTarget:memory.peak_pss_kib*1024<=4294967296,within5SecondMedianTarget:(times[2]+times[3])/2<=5000,quality:assessed.map(r=>({id:r.id,top3:r.order.slice(0,3),baseline:r.baseline,suggested:r.suggested})),improvedPresentations:assessed.filter(r=>r.suggested.ndcgAt3>r.baseline.ndcgAt3).length,worsenedPresentations:assessed.filter(r=>r.suggested.ndcgAt3<r.baseline.ndcgAt3).length,unchangedPresentations:assessed.filter(r=>r.suggested.ndcgAt3===r.baseline.ndcgAt3).length,identicalOrdersAcrossPresentation:inputs.filter(i=>{const pair=assessed.filter(r=>r.case===i.case);return JSON.stringify(pair[0].order)===JSON.stringify(pair[1].order);}).length,rankerQualifiedForIntegration:false};
const elapsed=rows.map(r=>r.totalMs).sort((a,b)=>a-b);
summary.medianModelRequestMs=summary.medianAdditionalRankingMs;summary.maxModelRequestMs=summary.maxAdditionalRankingMs;
summary.medianAdditionalRankingMs=(elapsed[2]+elapsed[3])/2;summary.maxAdditionalRankingMs=elapsed.at(-1);
await mkdir(output);await mkdir(join(output,'validation'));
for(const file of ['manifest.json','freeze.json','assessment.json','relevance.json','native.json','runtime.json'])await copyFile(join(run,file),join(output,file));
for(const file of ['rankings.jsonl','responses.jsonl','retrieval.jsonl','runtime.log'])await gzip(join(run,file),join(output,file+'.gz'));
await copyFile(join(prepared,'prepared.json'),join(output,'prepared.json'));
await gzip(join(prepared,'inputs.json'),join(output,'inputs.json.gz'));
await gzip('/tmp/vizzi-search.memory.json',join(output,'memory.json.gz'));
await gzip('/tmp/vizzi-search-run.log',join(output,'run.log.gz'));
await save(join(output,'summary.json'),summary);
const historical=[];
for(const dir of await readdir('experiments/qa/results',{withFileTypes:true})){
 if(!dir.isDirectory()||dir.name==='search')continue;
 const root=join('experiments/qa/results',dir.name);let checks;
 try{checks=await json(join(root,'checksums.json'));}catch(e){if(e.code==='ENOENT')continue;throw e;}
 let count=0;
 if(checks.sha256){for(const [path,hash] of Object.entries(checks.sha256)){assert.equal(await digest(join(root,path)),hash);count++;}}
 else{assert.equal(dir.name,'pilot');const {createHash}=await import('node:crypto');for(const [path,info] of Object.entries(checks)){const data=gunzipSync(await readFile(join(root,path)));assert.equal(createHash('sha256').update(data).digest('hex'),info.sha256_uncompressed);assert.equal(data.length,info.uncompressed_bytes);count++;}}
 historical.push({archive:dir.name,files:count});
}
await save(join(output,'integrity.json'),{schema:1,allFreezeHashesStillMatch:true,sourceArchiveUnchanged:true,sourceRevision:manifest.sourceRevision,indexVersionChangeRecorded:true,currentIndexSnapshot:manifest.expectedSnapshot,gradesFrozenBeforeModelStartup:true,modelAndRuntimeUnchanged:true,rawResponsesMatchParsedResults:true,allSixOrdersCompleteAndSourceBound:true,allCacheReuseZero:true,reversedPresentationsOnlyReorderSameCards:true,ownedProcessesStopped:true,reservedGenerations:0,historicalChecksumsVerified:historical});
const mutation=await json('/tmp/vizzi-search-node-mutations.json'),survivors=[];let caught=0;
const reasons={8:'For JSON question values, non-strings are still rejected by the following trim/Buffer operation. This removes only the early type diagnostic; executable objects are outside the JSON input contract.',184:'A missing planned row is still rejected by the following row.case access; only rejection diagnostics change.'};
for(const [file,v] of Object.entries(mutation.files))for(const m of v.mutants){if(m.status==='Killed'){caught++;continue;}assert.equal(m.status,'Survived');assert.ok(reasons[m.id]);survivors.push({file,id:m.id,location:m.location,mutator:m.mutatorName,replacement:m.replacement,reason:reasons[m.id]});}
assert.equal(caught,191);assert.equal(survivors.length,2);
await save(join(output,'mutation-exclusions.json'),{schema:1,node:{scope:'Whole search-support.mjs; CLI/HTTP transport outside mutation scope.',caught,equivalentSurvivors:survivors.length,timeouts:0,errors:0,noCoverage:0,rawScore:98.96,rawToolExit:1,sourceSha256:await digest('experiments/qa/search-support.mjs'),exclusions:survivors},rust:{scope:'Whole crates/vizzi-qa/src/ranking.rs; native JSON-line handler outside mutation scope.',caught:3,unviable:1,missed:0,timeouts:0,sourceSha256:await digest('crates/vizzi-qa/src/ranking.rs'),unviableReason:'Generated success stub requires Evidence: Default, which is not implemented. Compilation failure is separate from mutations caught by tests.'}});
for(const name of ['workspace','all-node','clippy','fmt','build','native-red','native-green','protocol-red','node-red','node-green','ledger-red','grade-key-red','cards-red','prepare'])await gzip('/tmp/vizzi-search-'+name+'.log',join(output,'validation',name+'.log.gz'));
for(const [from,to] of [['/tmp/vizzi-search-node-mutations.json','node-mutations.json.gz'],['/tmp/vizzi-search-node-mutants.log','node-mutations.log.gz'],['/tmp/vizzi-search-node-mutations.initial.json','initial-node-mutations.json.gz'],['/tmp/vizzi-search-node-mutants.initial.log','initial-node-mutations.log.gz'],['/tmp/vizzi-search-mutants.log','rust-mutations.log.gz'],['/tmp/vizzi-search-mutants/mutants.out/outcomes.json','rust-outcomes.json.gz'],['/tmp/vizzi-search-mutants/mutants.out/mutants.json','rust-mutants.json.gz'],['/tmp/vizzi-search-mutants/mutants.out/log/crates__vizzi-qa__src__ranking.rs_line_15_col_9_001.log','rust-unviable-build.log.gz']])await gzip(from,join(output,'validation',to));
await save(join(output,'validation.json'),{schema:1,native:'Fresh full workspace tests/doctests: 456 pass. Formatting and all-target Clippy pass; optimized native host/observer build pass. No browser/UI changes.',node:'All 19 serial QA test files pass. TDD logs retain missing-method/module and protocol/ledger/card/key regression failures before implementation/fixes.',mutations:'Portable module: 3 caught, 1 unviable, 0 missed/timeouts. Whole Node helper: 191 caught, 2 reviewed equivalents, 0 timeouts/errors/no-coverage; raw 98.96, exit 1 at threshold 100. Initial survivors led to stronger bounds, multi-question, ledger and fallback tests plus canonical grade-key validation. Native/HTTP transport outside mutation scopes.',inference:'Six serial requests after all build/correctness/mutation work; CPU only, two inference/prefill threads, nice 10. One native index and one model server. Both stopped.',scope:'Known maintainer questions and source-aware agent relevance grades. Reranking only, no generated answer. One cached 0.8B model/prompt, no tuning or retries after inference; all eight reserved cases unrun. Not independent usefulness acceptance or whole-repository qualification.'});
let trial='# Inspect the source-ranking trial\n\nFor the maintainer comparing search orders. These are exact source cards from the pinned\nlpc-rs revision `'+manifest.sourceRevision+'`. All cards remain available in every order.\nThe model supplies labels only; it supplies no answer or explanation. Grades in the separate\naudit are preliminary source-aware judgments, not a model confidence score.\n\n';
for(const input of inputs){
 const suffix=input.case.split('.').at(-1),pair=assessed.filter(r=>r.case===input.case);
 trial+='## '+input.question+'\n\n| Order | First three source labels |\n| --- | --- |\n';
 for(const [name,labels] of [['Baseline',input.context.evidence.map(e=>e.label)],...pair.map(p=>[p.reverse?'Model, reversed presentation':'Model, forward presentation',p.order])])trial+='| '+name+' | '+labels.slice(0,3).map(n=>'['+n+'](#'+suffix+'-'+n+')').join(', ')+' |\n';
 trial+='\nMissing from this pool: '+ratings.cases[input.case].missing_expected_sources.join(' ')+'\n\n';
 for(const e of input.context.evidence){const backticks=[...e.text.matchAll(/`+/g)].map(m=>m[0].length),fence='`'.repeat(Math.max(3,...backticks.map(n=>n+1)));trial+='<a id="'+suffix+'-'+e.label+'"></a>\n\n### '+e.label+'. '+e.path+':'+e.start_line+'–'+e.end_line+'\n\n'+(e.scope?'Scope: `'+[...e.scope.parents,e.scope.name].join('::')+'`. ':'')+'Role hint: `'+e.role+'`.\n\n'+fence+'\n'+e.text+'\n'+fence+'\n\n';}
}
await writeFile(join(output,'trial.md'),trial.trimEnd()+'\n',{flag:'wx'});
await gzip('/tmp/vizzi-search-archive.mjs',join(output,'archive.mjs.gz'));
const files=[];async function collect(path){for(const entry of await readdir(join(output,path),{withFileTypes:true})){const part=join(path,entry.name);if(entry.isDirectory())await collect(part);else files.push(part);}}await collect('');
const sha256={};for(const file of files.sort())sha256[file]=await digest(join(output,file));await save(join(output,'checksums.json'),{schema:1,sha256});
console.log(JSON.stringify({artifacts:files.length,historicalArchives:historical.length,historicalFiles:historical.reduce((n,h)=>n+h.files,0),summary},null,2));
