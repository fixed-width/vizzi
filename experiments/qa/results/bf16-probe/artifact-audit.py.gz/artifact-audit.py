import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0,'/tmp/vizzi-qa-weight-edit/llama-source/gguf-py')
from gguf import GGUFReader

out=Path('experiments/qa/library/token-bf16');out.mkdir()
old=json.loads(Path('experiments/qa/library/weight-edit/models.json').read_text())
build=json.loads(Path('experiments/qa/results/weight-edit/build.json').read_text())
paths={'q4':Path('/tmp/vizzi-qa-weight-edit/models/base/model-q4.gguf'),'bf16':Path('/tmp/vizzi-qa-weight-edit/base/model-bf16.gguf')}
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
hashes={name:digest(path) for name,path in paths.items()}
assert hashes['q4']==old['models'][0]['sha256']
assert hashes['bf16']==build['files'][str(paths['bf16'])]
readers={name:GGUFReader(path) for name,path in paths.items()}
def fields(reader):
    result={}
    for name,field in reader.fields.items():
        h=hashlib.sha256(json.dumps([int(k) for k in field.types]).encode())
        for part in field.parts:
            h.update(part.dtype.str.encode());h.update(json.dumps(list(part.shape)).encode());h.update(memoryview(part).cast('B'))
        result[name]=h.hexdigest()
    return result
metadata={name:fields(reader) for name,reader in readers.items()}
assert metadata['q4'].keys()==metadata['bf16'].keys()
differences=[key for key in metadata['q4'] if metadata['q4'][key]!=metadata['bf16'][key]]
assert differences==['general.file_type'],differences
shapes={name:{t.name:t.shape.tolist() for t in reader.tensors} for name,reader in readers.items()}
assert shapes['q4']==shapes['bf16']
audit={'schema':1,'sourceBuildSha256':digest(Path('experiments/qa/results/weight-edit/build.json')),'hashes':hashes,'bytes':{name:path.stat().st_size for name,path in paths.items()},'metadataFingerprints':metadata,'allowedMetadataDifferences':differences,'fileTypes':{name:reader.get_field('general.file_type').contents() for name,reader in readers.items()},'logicalTensorShapes':shapes['q4'],'tensors':len(shapes['q4']),'tensorTypes':{name:{t.name:int(t.tensor_type) for t in reader.tensors} for name,reader in readers.items()},'storageOrderEqual':[t.name for t in readers['q4'].tensors]==[t.name for t in readers['bf16'].tensors]}
Path('/tmp/vizzi-qa-bf16-model-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
config={'schema':1,'catalog_checked_on':'2026-11-06','selection_reason':'Matched cached BF16 intermediate and Q4_K_M derivative from the same source/converter; no model-generation change.','runtime':old['runtime'],'limits':old['limits'],'artifactAuditSha256':digest(Path('/tmp/vizzi-qa-bf16-model-audit.json')),'models':[]}
for name,reader in readers.items():
    model={**old['models'][0]}
    if name=='q4':model['directory']='models/base'
    else:model.update(id='qwen3.5-0.8b-base-local-bf16',directory='base',filename='model-bf16.gguf',bytes=paths[name].stat().st_size,sha256=hashes[name],artifact_kind='Locally converted BF16 intermediate, including F32 tensors; same source as Q4 derivative')
    assert hashlib.sha256(reader.get_field('tokenizer.chat_template').contents().encode()).hexdigest()==model['chat_template_sha256']
    config['models'].append(model)
(out/'models.json').write_text(json.dumps(config,indent=2)+'\n')
original=json.loads(Path('experiments/qa/library/token-probe/cohort.json').read_text())
for name in ['control','bf16']:
    spec={**original,'models':'experiments/qa/library/token-bf16/models.json','model':config['models'][name=='bf16']['id'],'protocol':'docs/qa/BF16_PROBE.md','referenceArchive':'experiments/qa/results/token-probe/preflight.json.gz','referenceChecksums':'experiments/qa/results/token-probe/checksums.json'}
    (out/(name+'.json')).write_text(json.dumps(spec,indent=2)+'\n')
print('Verified cached hashes, 335 matching logical tensors and all metadata except file type; froze two cohorts.')
