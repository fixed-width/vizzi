import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,copyFile,readdir} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync} from 'node:zlib';
import {comparePrecisionProbes,assertProbeReference} from '/home/mpd/git-sources/vizzi/experiments/qa/precision-probe-support.mjs';
import {readProbe} from '/home/mpd/git-sources/vizzi/experiments/qa/token-probe-support.mjs';
import {verifyHashes} from '/home/mpd/git-sources/vizzi/experiments/qa/compact-support.mjs';

const root='experiments/qa/results/bf16-probe';
const json=async path=>JSON.parse(await readFile(path,'utf8'));
const digest=data=>createHash('sha256').update(data).digest('hex');
const fileHash=async path=>digest(await readFile(path));
const save=async(path,value)=>writeFile(path,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const gzip=async(from,to)=>writeFile(to,gzipSync(await readFile(from)),{flag:'wx'});
const lines=async path=>(await readFile(path,'utf8')).trim().split('\n').map(JSON.parse);
const percentile=(a,p)=>[...a].sort((x,y)=>x-y)[Math.ceil(p*a.length)-1];
const median=a=>{const b=[...a].sort((x,y)=>x-y);return (b[b.length/2-1]+b[b.length/2])/2;};
const spec=await json('experiments/qa/library/token-bf16/control.json');
const audit=await json('/tmp/vizzi-qa-bf16-model-audit.json');
const models=await json(spec.models);
assert.equal(await fileHash('/tmp/vizzi-qa-bf16-model-audit.json'),models.artifactAuditSha256);
assert.deepEqual(audit.allowedMetadataDifferences,['general.file_type']);assert.equal(audit.tensors,335);
const runs={};
for(const [name,label] of [['control','q4'],['candidate','bf16']]){
 const path='/tmp/vizzi-qa-bf16-'+name+'-run',preparedPath='/tmp/vizzi-qa-bf16-'+name+'-prepared';
 const manifest=await json(join(path,'manifest.json')),runtime=await json(join(path,'runtime.json'));
 const prepared=await json(join(preparedPath,'prepared.json')),preflight=await json(join(path,'preflight.json'));
 const rows=await lines(join(path,'probes.jsonl')),responses=await lines(join(path,'responses.jsonl'));
 const memory=await json('/tmp/vizzi-qa-bf16-'+name+'.memory.json');
 assert.equal(manifest.completed,32);assert.equal(manifest.incomplete,false);assert.equal(manifest.reservedGenerations,0);
 assert.equal(manifest.preparedSha256,await fileHash(join(preparedPath,'prepared.json')));
 await verifyHashes(prepared.files);assert.deepEqual(manifest.model,prepared.model);
 assert.equal(manifest.model.sha256,audit.hashes[label]);
 assert.equal(rows.length,32);assert.equal(responses.length,32);
 assert.equal(memory.success,true);assert.equal(memory.child_exit_code,0);assert.equal(memory.mode,'observe_only');
 assert.equal(memory.cap_verified,false);assert.deepEqual(memory.errors,[]);
 for(const s of memory.samples)assert.deepEqual(s.errors,[]);
 assert.throws(()=>process.kill(runtime.pid,0),{code:'ESRCH'});
 assertProbeReference(await json(join(preparedPath,'reference.json')),preflight,spec);
 for(const [i,row] of rows.entries()){
  assert.equal(responses[i].id,row.id);assert.deepEqual(responses[i].response,row.response);assert.deepEqual(responses[i].request,row.request);
  assert.deepEqual(readProbe(row.response,preflight.candidates[row.prefix],row.promptTokens,spec.topCount),row.measurement);
  assert.equal(row.response.timings.cache_n,0);assert.equal(row.response.timings.prompt_n,row.promptTokens);
  assert.equal(row.response.generation_settings.backend_sampling,false);
 }
 let identicalRepeats=0;
 for(const row of rows.filter(r=>r.repeat===1)){
  const again=rows.find(r=>r.case===row.case&&r.system===row.system&&r.prefix===row.prefix&&r.repeat===2);
  assert.deepEqual(row.measurement,again.measurement);identicalRepeats++;
 }
 const times=rows.map(r=>r.totalMs),first=rows.filter(r=>r.repeat===1);
 const censoring=Object.fromEntries(['Yes','No','Unknown'].map(k=>[k,rows.filter(r=>r.measurement.choices[k].censored).length]));
 const mass=system=>{const a=rows.filter(r=>r.system===system).map(r=>r.measurement.observedChoiceMass);return {min:Math.min(...a),max:Math.max(...a)};};
 const resource={peakPssKiB:memory.peak_pss_kib,peakPssGiB:memory.peak_pss_kib/1048576,peakRssKiB:memory.peak_rss_kib,wallMs:memory.wall_ms,startupMs:runtime.startupMs,medianObservationMs:median(times),p95ObservationMs:percentile(times,.95),within4GiBObservedTarget:memory.peak_pss_kib*1024<=4294967296,samplingErrors:memory.errors.length,samples:memory.samples.length};
 runs[label]={model:manifest.model,preflight,rows,path,preparedPath,memory,resource,censoring,identicalRepeats,observedChoiceMass:{production:mass('production'),diagnostic:mass('diagnostic')},first:first.map(r=>({case:r.case,system:r.system,prefix:r.prefix,margin:r.measurement.marginYesNo,globalTop:r.measurement.top,choiceWinner:r.measurement.winner,observedChoiceMass:r.measurement.observedChoiceMass}))};
}
const comparison=comparePrecisionProbes(runs.q4,runs.bf16,spec);
const historical=gunzipSync(await readFile('experiments/qa/results/token-probe/probes.jsonl.gz')).toString().trim().split('\n').map(JSON.parse);
assert.deepEqual(runs.q4.rows.map(r=>r.measurement),historical.map(r=>r.measurement));
assert.deepEqual(runs.q4.rows.map(r=>r.request),historical.map(r=>r.request));
assert.equal(await fileHash(join(runs.q4.preparedPath,'inputs.json')),await fileHash(join(runs.bf16.preparedPath,'inputs.json')));
const historicalChecks=[];
for(const dir of await readdir('experiments/qa/results',{withFileTypes:true})){
 if(!dir.isDirectory()||dir.name==='bf16-probe')continue;
 const base=join('experiments/qa/results',dir.name);let checks;
 try{checks=await json(join(base,'checksums.json'));}catch(e){if(e.code==='ENOENT')continue;throw e;}
 let n=0;
 if(checks.sha256){for(const [path,hash] of Object.entries(checks.sha256)){assert.equal(await fileHash(join(base,path)),hash,join(base,path));n++;}}
 else {assert.equal(dir.name,'pilot');for(const [path,info] of Object.entries(checks)){const bytes=gunzipSync(await readFile(join(base,path)));assert.equal(digest(bytes),info.sha256_uncompressed);assert.equal(bytes.length,info.uncompressed_bytes);n++;}}
 historicalChecks.push({archive:dir.name,files:n});
}
await mkdir(root);await mkdir(join(root,'validation'));
for(const [name,run] of Object.entries(runs)){
 const out=join(root,name);await mkdir(out);
 for(const file of ['manifest.json','runtime.json','effects.json'])await copyFile(join(run.path,file),join(out,file));
 for(const file of ['runtime.log','preflight.json','probes.jsonl','responses.jsonl'])await gzip(join(run.path,file),join(out,file+'.gz'));
 const tag=name==='q4'?'control':'candidate';
 await gzip('/tmp/vizzi-qa-bf16-'+tag+'.memory.json',join(out,'memory.json.gz'));
 await gzip('/tmp/vizzi-qa-bf16-'+tag+'-run.log',join(out,'run.log.gz'));
 await copyFile(join(run.preparedPath,'prepared.json'),join(out,'prepared.json'));
 await copyFile('experiments/qa/library/token-bf16/'+(name==='q4'?'control':'bf16')+'.json',join(out,'cohort.json'));
}
await gzip(join(runs.q4.preparedPath,'inputs.json'),join(root,'inputs.json.gz'));
await gzip('/tmp/vizzi-qa-bf16-model-audit.json',join(root,'artifact-audit.json.gz'));
await gzip('/tmp/vizzi-qa-bf16-model-audit.py',join(root,'artifact-audit.py.gz'));
await copyFile(spec.models,join(root,'models.json'));
await save(join(root,'comparison.json'),comparison);
await save(join(root,'summary.json'),{schema:1,reservedGenerations:0,observationsPerArtifact:32,uniqueConditionsPerArtifact:16,historicalQ4MeasurementsExactlyReproduced:32,pairedInputs:comparison.inputs,models:Object.fromEntries(Object.entries(runs).map(([name,r])=>[name,{model:r.model,resource:r.resource,censoring:r.censoring,identicalRepeatPairs:r.identicalRepeats,observedChoiceMass:r.observedChoiceMass,firstPass:r.first}]))});
await save(join(root,'integrity.json'),{schema:1,matchedArtifactBuild:true,metadataOnlyFileTypeDiffers:true,logicalTensorShapesIdentical:335,preflightConditionsByteAndTokenIdentical:16,candidateSpellingsIdentical:6,historicalQ4MeasurementsIdentical:32,rawAndParsedResponsesMatch:64,allMeasuredCacheReuseZero:true,allPromptTokenCountsMatch:true,backendSampling:false,identicalRepeatPairs:32,ownedServersStopped:true,reservedGenerations:0,historicalChecksumsVerified:historicalChecks});
await copyFile('experiments/qa/results/token-probe/native-baseline.json',join(root,'native-baseline.json'));
const mutation=await json('/tmp/vizzi-qa-bf16-probe-mutations.json'),survivors=[];
const reasons={
 'experiments/qa/precision-probe-support.mjs:6':'probePlan requires exactly two complete passes with identical condition sets. Selecting pass 2 instead of pass 1 yields the same sorted condition keys; no probabilities or row pairing use this filter.',
 'experiments/qa/token-probe-support.mjs:241':'After the earlier both-observed branch fails, an observed finite No implies Yes is censored. The null check is redundant for parser-produced finite/null choices.',
 'experiments/qa/token-probe-support.mjs:303':'A missing planned row is still rejected immediately at the following r.case property access; only rejection diagnostics change.'};
let killed=0;
for(const [file,data] of Object.entries(mutation.files))for(const m of data.mutants){if(m.status==='Killed'){killed++;continue;}assert.equal(m.status,'Survived');const reason=reasons[file+':'+m.id];assert.ok(reason);survivors.push({file,id:m.id,location:m.location,mutator:m.mutatorName,replacement:m.replacement,reason});}
assert.equal(killed,300);assert.equal(survivors.length,3);
await save(join(root,'mutation-equivalents.json'),{schema:1,scope:'Whole token-probe-support.mjs and precision-probe-support.mjs; CLI transport outside mutation scope.',counts:{caught:killed,equivalentSurvivors:survivors.length,timeouts:0,errors:0,noCoverage:0},rawScore:99.01,rawToolExit:1,sourceSha256:Object.fromEntries(await Promise.all(Object.keys(mutation.files).map(async file=>[file,await fileHash(file)]))),exclusions:survivors});
for(const [from,to] of [['node','qa-node.log'],['clippy','clippy.log'],['mutants','mutations.log'],['green','focused-green.log'],['red','focused-red.log']])await gzip('/tmp/vizzi-qa-bf16-probe-'+from+'.log',join(root,'validation',to+'.gz'));
await gzip('/tmp/vizzi-qa-bf16-probe-mutations.json',join(root,'validation','mutations.json.gz'));
await gzip('/tmp/vizzi-qa-bf16-assess.mjs',join(root,'assess.mjs.gz'));
await save(join(root,'validation.json'),{schema:1,node:'18 serial QA test files pass; focused tests first fail without the new helper, then pass. Model integration: 64 successful one-token observations with matching preflights.',native:'Production Rust/Cargo inputs match d15a56d. Retain its passing 453-test/doctest baseline, not rerun; fresh workspace formatting/all-target Clippy pass.',mutations:'300 caught, 3 documented equivalents; zero timeouts/errors/no-coverage. Single low-priority worker; raw 99.01, exit 1 at threshold 100. CLI transport outside mutation scope.',measurement:'All correctness/mutation work finishes before serial Q4 then BF16 measurement. CPU-only, two inference/prefill threads, nice 10, cold prefill, one owned server resident at a time. Both servers stopped.',limitations:'Known synthetic conditional next-token readouts, not complete QA, calibrated confidence, or causal circuit evidence. Source metadata and prefix/instruction interventions remain. No new weights, dependencies, training or reserved inference.',testAndConfigSha256:Object.fromEntries(await Promise.all(['experiments/qa/bf16-probe.test.mjs','experiments/qa/token-probe.test.mjs','experiments/qa/token-probe-stryker.config.json','package-lock.json'].map(async file=>[file,await fileHash(file)])))});
const files=[];
async function collect(path){for(const item of await readdir(join(root,path),{withFileTypes:true})){const part=join(path,item.name);if(item.isDirectory())await collect(part);else files.push(part);}}
await collect('');const hashes={};for(const file of files.sort())hashes[file]=await fileHash(join(root,file));
await save(join(root,'checksums.json'),{schema:1,sha256:hashes});
console.log(JSON.stringify({artifacts:files.length,historicalArchives:historicalChecks.length,historicalFiles:historicalChecks.reduce((n,c)=>n+c.files,0),summary:Object.fromEntries(Object.entries(runs).map(([name,r])=>[name,{resource:r.resource,censoring:r.censoring,identicalRepeatPairs:r.identicalRepeats,observedChoiceMass:r.observedChoiceMass}])),effects:Object.fromEntries(Object.entries(comparison.effects).map(([name,rows])=>[name,rows.filter(r=>r.repeat===1)]))},null,2));
