import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,copyFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {gzipSync,gunzipSync} from 'node:zlib';
import {cpus,totalmem} from 'node:os';
import {json,digest} from '/home/mpd/git-sources/vizzi/experiments/qa/support.mjs';
import {verifyHashes} from '/home/mpd/git-sources/vizzi/experiments/qa/compact-support.mjs';
import {assessCoverage,locateTarget} from '/home/mpd/git-sources/vizzi/experiments/qa/coverage-support.mjs';
const root='experiments/qa/results/search-coverage',run='/tmp/vizzi-search-coverage-run',prepared='/tmp/vizzi-search-coverage-prepared';
const save=(p,v)=>writeFile(p,JSON.stringify(v,null,2)+'\n',{flag:'wx'}),gzip=async(a,b)=>writeFile(b,gzipSync(await readFile(a)),{flag:'wx'});
const lines=async p=>(await readFile(p,'utf8')).trim().split('\n').map(JSON.parse);
const spec=await json('experiments/qa/library/search-coverage/cohort.json'),prep=await json(join(prepared,'prepared.json')),freeze=await json(join(run,'freeze.json'));
const rows=await lines(join(run,'retrieval.jsonl')),raw=await lines(join(run,'responses.jsonl')),assessment=assessCoverage(rows,spec.cases,prep.expectedSnapshot),native=await json(join(run,'native.json')),manifest=await json(join(run,'manifest.json')),memory=await json('/tmp/vizzi-search-coverage.memory.json');
await verifyHashes(freeze.files);assert.deepEqual(assessment,await json(join(run,'assessment.json')));
assert.equal(rows.length,90);assert.equal(raw.length,90);assert.equal(manifest.complete,true);assert.equal(manifest.modelRequests,0);assert.equal(manifest.reservedGenerations,0);
for(const [i,row]of rows.entries()){assert.equal(raw[i].id,row.id);assert.deepEqual(raw[i].response.context,row.context);assert.equal(raw[i].response.elapsed_ms,row.elapsedMs);assert.equal(raw[i].roundTripMs,row.roundTripMs);}
for(const c of spec.cases)for(const selector of spec.selectors){const group=rows.filter(r=>r.case===c.id&&r.selector===selector);assert.equal(group.length,3);assert.deepEqual(group[0].context,group[1].context);assert.deepEqual(group[0].context,group[2].context);}
assert.equal(memory.success,true);assert.equal(memory.child_exit_code,0);assert.equal(memory.mode,'observe_only');assert.equal(memory.cap_verified,false);assert.deepEqual(memory.errors,[]);for(const s of memory.samples)assert.deepEqual(s.errors,[]);
assert.throws(()=>process.kill(native.pid,0),{code:'ESRCH'});
const median=a=>{const b=[...a].sort((x,y)=>x-y),m=Math.floor(b.length/2);return b.length%2?b[m]:(b[m-1]+b[m])/2;};
const metrics={};for(const selector of spec.selectors){const selected=rows.filter(r=>r.selector===selector);metrics[selector]={observations:selected.length,medianNativeMs:median(selected.map(r=>r.elapsedMs)),medianRoundTripMs:median(selected.map(r=>r.roundTripMs)),minNativeMs:Math.min(...selected.map(r=>r.elapsedMs)),maxNativeMs:Math.max(...selected.map(r=>r.elapsedMs)),withinOneSecondMedianTarget:median(selected.map(r=>r.elapsedMs))<=1000};}
const perCase=spec.cases.map(c=>({id:c.id,question:c.question,group:c.group,selectors:Object.fromEntries(spec.selectors.map(selector=>{const item=assessment.find(r=>r.case===c.id&&r.selector===selector&&r.repeat===1);return[selector,{found:item.targets.filter(t=>t.foundRank!==null).length,literal:item.targets.filter(t=>t.literalRank!==null).length,total:item.targets.length,targets:item.targets,medianNativeMs:median(rows.filter(r=>r.case===c.id&&r.selector===selector).map(r=>r.elapsedMs))}];}))}));
const known=perCase.filter(c=>c.group==='maintainer'),controls=perCase.filter(c=>c.group==='regression');
const old=JSON.parse(gunzipSync(await readFile('experiments/qa/results/search/inputs.json.gz'))),historicalMaintainer=known.map(c=>{const context=old.find(i=>i.case===c.id).context,targets=spec.cases.find(i=>i.id===c.id).targets.map(t=>locateTarget(context,t));return {case:c.id,targets,found:targets.filter(t=>t.foundRank!==null).length,literal:targets.filter(t=>t.literalRank!==null).length};});
const sum=(cases,selector,field)=>cases.reduce((n,c)=>n+c.selectors[selector][field],0);
const summary={schema:1,questions:15,repeats:3,observations:90,modelRequests:0,reservedGenerations:0,sourceRevision:prep.sourceRevision,sourceArchiveSha256:prep.sourceArchiveSha256,indexSnapshot:prep.expectedSnapshot,capture:native.ready,environment:{cpu:cpus()[0].model,physicalMemoryBytes:totalmem()},metrics,peakPssKiB:memory.peak_pss_kib,peakPssGiB:memory.peak_pss_kib/1048576,within4GiBObservedTarget:memory.peak_pss_kib*1024<=4294967296,wholeObservedMs:memory.wall_ms,samplingErrors:0,identicalRepeatedPools:30,maintainerTargets:{total:7,compactFound:sum(known,'compact','found'),searchFound:sum(known,'search','found'),compactLiteral:sum(known,'compact','literal'),searchLiteral:sum(known,'search','literal')},regressionTargets:{total:sum(controls,'compact','total'),compactFound:sum(controls,'compact','found'),searchFound:sum(controls,'search','found'),identicalPools:controls.filter(c=>{const a=rows.find(r=>r.case===c.id&&r.selector==='compact'),b=rows.find(r=>r.case===c.id&&r.selector==='search');return JSON.stringify(a.context)===JSON.stringify(b.context);}).length,worsenedQuestions:controls.filter(c=>c.selectors.search.found<c.selectors.compact.found).map(c=>c.id)},perCase,historicalMaintainer};
await mkdir(root);await mkdir(join(root,'validation'));
for(const file of ['manifest.json','freeze.json','native.json','assessment.json'])await copyFile(join(run,file),join(root,file));
for(const file of ['responses.jsonl','retrieval.jsonl'])await gzip(join(run,file),join(root,file+'.gz'));
await copyFile(join(prepared,'prepared.json'),join(root,'prepared.json'));await copyFile(join(prepared,'source-audit.json'),join(root,'source-audit.json'));
await copyFile('experiments/qa/library/search-coverage/cohort.json',join(root,'cohort.json'));
await gzip('/tmp/vizzi-search-coverage.memory.json',join(root,'memory.json.gz'));await gzip('/tmp/vizzi-coverage-run.log',join(root,'run.log.gz'));
await save(join(root,'summary.json'),summary);
const historical=[];for(const d of await readdir('experiments/qa/results',{withFileTypes:true})){
 if(!d.isDirectory()||d.name==='search-coverage')continue;const base=join('experiments/qa/results',d.name);let checks;
 try{checks=await json(join(base,'checksums.json'));}catch(e){if(e.code==='ENOENT')continue;throw e;}
 let count=0;if(checks.sha256){for(const [p,h]of Object.entries(checks.sha256)){assert.equal(await digest(join(base,p)),h);count++;}}
 else{assert.equal(d.name,'pilot');const{createHash}=await import('node:crypto');for(const[p,info]of Object.entries(checks)){const data=gunzipSync(await readFile(join(base,p)));assert.equal(createHash('sha256').update(data).digest('hex'),info.sha256_uncompressed);assert.equal(data.length,info.uncompressed_bytes);count++;}}
 historical.push({archive:d.name,files:count});
}
await save(join(root,'integrity.json'),{schema:1,sourceArchivePinned:true,allFrozenHashesStillMatch:true,allReturnedPoolsNativeBound:true,rawResponsesMatchAssessment:true,allThirtyRepeatedPoolsIdentical:true,sourceIndexVersionChangeRecorded:true,ownedNativeStopped:true,modelRequests:0,reservedGenerations:0,historicalChecksumsVerified:historical});
for(const name of ['macro-red','discovery-red','protocol-red','browser-red','focused','strengthened','core','compact','node-red','node-green','id-red','workspace','all-node','fmt','clippy','build','browser','prepare'])await gzip('/tmp/vizzi-coverage-'+name+'.log',join(root,'validation',name+'.log.gz'));
for(const[a,b]of [
 ['/tmp/vizzi-coverage-rust-initial/outcomes.json','rust-initial-outcomes.json.gz'],['/tmp/vizzi-coverage-rust-initial/mutants.json','rust-initial-mutants.json.gz'],['/tmp/vizzi-coverage-rust-initial.log','rust-initial.log.gz'],
 ['/tmp/vizzi-coverage-rust-mutants/mutants.out/outcomes.json','rust-retest-outcomes.json.gz'],['/tmp/vizzi-coverage-rust-retest.log','rust-retest.log.gz'],
 ['/tmp/vizzi-coverage-shared-initial/outcomes.json','shared-initial-outcomes.json.gz'],['/tmp/vizzi-coverage-shared-initial.log','shared-initial.log.gz'],
 ['/tmp/vizzi-coverage-shared-mutants/mutants.out/outcomes.json','shared-retest-outcomes.json.gz'],['/tmp/vizzi-coverage-shared-retest.log','shared-retest.log.gz'],['/tmp/vizzi-coverage-shared.diff','shared.diff.gz'],
 ['/tmp/vizzi-coverage-node-mutations.initial.json','node-initial-mutations.json.gz'],['/tmp/vizzi-coverage-node-mutants.initial.log','node-initial.log.gz'],
 ['/tmp/vizzi-coverage-node-mutations.json','node-mutations.json.gz'],['/tmp/vizzi-coverage-node-mutants.log','node-mutations.log.gz']])await gzip(a,join(root,'validation',b));
let trial='# Inspect source coverage for the maintainer questions\n\nFor the maintainer comparing deterministic source search. All source cards below come\nfrom the pinned lpc-rs revision `'+prep.sourceRevision+'`. These are locations and excerpts,\nnot generated answers or a resolved call graph. Scope and literal matches are recorded\nseparately in the assessment. The compact control shares the new macro-aware index.\n\n';
for(const c of known){
 const key=c.id.split('.').at(-1);trial+='## '+c.question+'\n\n| Target | Compact rank | Search rank | Search literal rank |\n| --- | ---: | ---: | ---: |\n';
 for(const target of c.selectors.search.targets){const baseline=c.selectors.compact.targets.find(t=>t.id===target.id);trial+='| '+target.id+' | '+(baseline.foundRank??'—')+' | '+(target.foundRank??'—')+' | '+(target.literalRank??'—')+' |\n';}
 trial+='\n';
 for(const selector of spec.selectors){trial+='### '+selector+' source cards\n\n';for(const e of rows.find(r=>r.case===c.id&&r.selector===selector&&r.repeat===1).context.evidence){const ticks=[...e.text.matchAll(/`+/g)].map(m=>m[0].length),fence='`'.repeat(Math.max(3,...ticks.map(n=>n+1)));trial+='#### '+e.label+'. '+e.path+':'+e.start_line+'–'+e.end_line+'\n\n'+(e.scope?'Scope: `'+[...e.scope.parents,e.scope.name].join('::')+'` ('+e.scope.kind+'). ':'')+'Role hint: `'+e.role+'`.\n\n'+fence+'\n'+e.text+'\n'+fence+'\n\n';}}
}
await writeFile(join(root,'trial.md'),trial.trimEnd()+'\n',{flag:'wx'});
await gzip('/tmp/vizzi-coverage-archive.mjs',join(root,'archive.mjs.gz'));
const files=[];async function collect(path){for(const e of await readdir(join(root,path),{withFileTypes:true})){const part=join(path,e.name);if(e.isDirectory())await collect(part);else files.push(part);}}await collect('');
const sha256={};for(const p of files.sort())sha256[p]=await digest(join(root,p));await save(join(root,'checksums.json'),{schema:1,sha256});
console.log(JSON.stringify({artifacts:files.length,historicalArchives:historical.length,historicalFiles:historical.reduce((n,h)=>n+h.files,0),metrics,peakPssGiB:summary.peakPssGiB,maintainerTargets:summary.maintainerTargets,regressionTargets:summary.regressionTargets,maintainer:known},null,2));
